# Musicstore-analysis
**DATABASE AND TOOLS**
**MYSQL**
DATA MODELLING 
![image](https://github.com/starlorsarkar/Musicstore-analysis/assets/149099969/92b2ddad-ed3c-4f84-9521-f2a8fca5f632)
